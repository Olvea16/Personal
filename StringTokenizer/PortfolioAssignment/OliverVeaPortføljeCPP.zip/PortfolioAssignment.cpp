#include "stdafx.h"
#include "StringTokenizer.h"

int main()
{
	StringTokenizer a("Delimiter betyder skilletegn. I en tekststreng adskilles de indg�ende tokens af delimiters, som har l�ngden �n karakter. Der kan godt komme flere delimiters umiddelbart efter hinanden.");
	cout << "Tekst: ";
	a.printContents();
	cout << "\n";
	cout << "Antal Tokens: " << a.countAllTokens() << "\nAntal Delimiters: " << a.countAllDelimiters() << endl << endl;
	cout << "Tokens:\n";
	for (int i = 0; i < a.countAllTokens(); i++) cout << a.nextToken() << "\n";
	cout << "Tekst indeholder Delimiter?: " << a.contains("Delimiter") << "\n";
	cout << "Tekst indeholder resultat?: " << a.contains("resultat") << "\n";
	system("Pause");
    return 0;
}

